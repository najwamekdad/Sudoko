module Sudoku {
	exports sudoku;

	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
	opens sudoku;
}