package sudoku;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;

/**
 * A class SudokuGUI describing the user graphic interface of sudoku puzzle.
 * @author najwa Mekdad
 * @author Shaza Saman
 * @author Mountaha
 *
 */
public class SudokuGUI {
	private SudokuSolver sudokuSolver;
	private BorderPane root;
	private OneLetterTextField[][] boxes;
     
	/**
	 * SudokuGUI constructor
	 */
	public SudokuGUI() {
		sudokuSolver = new SudokuSolver();

		boxes = new OneLetterTextField[9][9];

		root = new BorderPane();
		root.setCenter(makeGrid());
		root.setBottom(makeButtons());
	}

	/**
	 * Returns the root of the GUI.
	 * @return Parent object
	 */
	public Parent getRoot() {
		return root;
	}
    
	/**
	 * returns a grid consists of (9 * 9) of OneLetterTextFields
	 *  which contain numbers entered by user.
	 * @return TilePane object
	 */
	private TilePane makeGrid() {
		TilePane tp = new TilePane();

		tp.setPrefColumns(9);
		tp.setPrefRows(9);
		tp.setPadding(new Insets(3, 3, 3, 3));
		tp.setHgap(3);
		tp.setVgap(3);

		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				OneLetterTextField tf = new OneLetterTextField();
				tf.setPrefColumnCount(1);
				if (!(i / 3 == 1 || j / 3 == 1) || //corner box
						((i / 3 == 1 && j / 3 == 1))) { //center box
					tf.setStyle("-fx-background-color: #ff9933;");
				}
				
				boxes[i][j] = tf;
				tp.getChildren().add(tf);
			}
		}
		return tp;
	}

	/**
	 * returns buttons of (solve) and (clear) which display at bottom of the grid.
	 * @return HBox object
	 */
	private HBox makeButtons() {
		HBox hbox = new HBox();
		hbox.setPadding(new Insets(0, 3, 3, 3));
		hbox.setAlignment(Pos.CENTER);
		hbox.setSpacing(30);

		Button solveButton = new Button("Solve");
		solveButton.setStyle("-fx-base: #bcdf8a;");
		solveButton.setOnAction(e -> solve());

		Button clearButton = new Button("Clear");
		clearButton.setOnAction(e -> clear());

		hbox.getChildren().addAll(clearButton, solveButton);

		return hbox;

	}
	
    /**
     * this method is called when the user press button (solve).
     */
	private void solve() {
		// läser av värden från brädet
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				String s = boxes[i][j].getText();
				if (s.length() > 0) {
					sudokuSolver.setBox(i, j, Integer.valueOf(s));
				} else {
					sudokuSolver.setBox(i, j, 0);
				}
			}
		}

		if (sudokuSolver.solve()) {

			// skriver ut lösningen
			for (int i = 0; i < 9; i++) {
				for (int j = 0; j < 9; j++) {
					boxes[i][j].setText("" + sudokuSolver.getBox(i, j));
				}
			}
		} else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle(null);
			alert.setHeaderText(null);
			alert.setContentText("Sorry, Your entered numbers cannot resolve Sudoku!");
			alert.showAndWait();
		}
	}
	
    /**
     * this method is called when the user press button (clear).
     */
	private void clear() {
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				boxes[i][j].clear();
			}
		}
	}
}
