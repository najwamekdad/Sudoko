package sudoku;
import java.util.Optional;

import java.util.Arrays;
import java.util.Objects;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class SudokuSolverController extends Application  {
    
    @Override 
    
	public void start(Stage stage) { 
	SudokuGUI sg = new 	SudokuGUI();
	stage.setResizable(false);
	Scene scene = new Scene(sg.getRoot());
	stage.setScene(scene);
	stage.setTitle("Sudoko");
	stage.show();
	}
	
		
	public static void main(String[] args) {
       launch(args);
	}

}
