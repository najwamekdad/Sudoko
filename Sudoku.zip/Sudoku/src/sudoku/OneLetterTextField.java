package sudoku;

import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class OneLetterTextField extends TextField {

	@Override
	public void replaceText(int start, int end, String text) {
		if (matches(text)) {
			super.replaceText(start, end, text);
		}else {
			errorInput();
		}
	}
	
	@Override
	public void replaceSelection(String text) {
		if (matches(text)) {
			super.replaceSelection(text);
		}else {
			errorInput();
		}
	}

	private boolean matches(String text) {
		return text.isEmpty() || (getText().length() < 1) && text.matches("[1-9]") ;
	}
    
	private void errorInput() {
		Alert alert = new Alert (AlertType.ERROR);
		alert.setTitle("Error in input");
		alert.setHeaderText(null);
		alert.setContentText("Wrong input, you must enter a number between \"1\" and \"9\"!! ");
		alert.showAndWait();
		deleteText(0, getText().length());
	}
}

