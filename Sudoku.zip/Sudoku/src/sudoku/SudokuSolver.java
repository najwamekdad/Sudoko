package sudoku;

import java.util.Arrays;
/**
 * A class SudokuSolver describing a Sudoku puzzle and its solution that uses a so-called backtracking technique.
 * it is a ”puzzle” consisting of 9 * 9 boxes.
 *   Some boxes are initially filled in with numbers between 1 and 9.
 *   a solution that meets the following requirements:
 *   •Each box is filled with a number between 1 and 9.
 *   •Each row and every column, contains all the numbers between 1-9.
 *   •Each ”region” also contains the all numbers between 1-9.
    
 * @author Najwa Mekdad
 * @author Shaza Saman
 * @author Mountaha 
 *
 */
public class SudokuSolver {
	private int[][] grid;

	/**
	 * SudokuSolver constructor
	 */
	public SudokuSolver() {
		grid = new int[9][9];

	}
	
    /**
     * SudokuSolver constructor
     * @param grid corresponds to some boxes are initially filled in with numbers between 1 and 9
     */
	public SudokuSolver(int[][] grid) {
		this.grid = grid;

	}
    
	/**
	 * Returns the value at row i , col j in the sudoku grid.
	 * @param i row in the grid
	 * @param j column in the grid
	 * @return int value
	 */
	public int getBox(int i, int j) {
		return grid[i][j];
	}
	
	/**
	 * set a value at row i , col j in the sudoku grid.
	 * @param i row in the grid
	 * @param j column in the grid
	 * @param value which will be set
	 */
	public void setBox(int i, int j, int value) {
		grid[i][j] = value;
	}

	/**
	 * Returns true if the grid meets all requirements in sudoku puzzle, otherwise returns false.
	 * @return boolean value
	 */
	private boolean checkGrid() {
		// check each region
		int n = grid.length;
		if (!checkRegion(0, n / 3, 0, n / 3) || !checkRegion(0, n / 3, n / 3, 2 * n / 3)
				|| !checkRegion(0, n / 3, 2 * n / 3, n) || !checkRegion(n / 3, 2 * n / 3, 0, n / 3)
				|| !checkRegion(n / 3, 2 * n / 3, n / 3, 2 * n / 3) || !checkRegion(n / 3, 2 * n / 3, 2 * n / 3, n)
				|| !checkRegion(2 * n / 3, n, 0, n / 3) || !checkRegion(2 * n / 3, n, n / 3, 2 * n / 3)
				|| !checkRegion(2 * n / 3, n, 2 * n / 3, n)) {
			return false;
		} else {
			// check each row and each col
			for (int i = 0; i < n; i++) {
				boolean[] rowChecked = new boolean[n + 1];
				boolean[] culmnChecked = new boolean[n + 1];
				for (int k = 0; k < n; k++) {
					int r = grid[i][k];
					int c = grid[k][i];
					if ((rowChecked[r] && r != 0) || (culmnChecked[c] && c != 0)) {
						return false;
					}
					rowChecked[r] = true;
					culmnChecked[c] = true;
				}
			}
			return true;
		}
	}

	/**
	 * returns true if a region in the grid meets the requirment for a region in sudoku puzzel, otherwise returns false.
	 * @param a the start index for the rows of the region 
	 * @param b the end index for the rows of the region
	 * @param c the start index for the cols of the region
	 * @param d the end index for the cols of the region
	 * @return boolean value
	 */
	private boolean checkRegion(int a, int b, int c, int d) {
		int n = grid.length;
		boolean[] elmentChecked = new boolean[n + 1];
		for (int i = a; i < b; i++) {
			for (int k = c; k < d; k++) {
				int v = grid[i][k];
				if (elmentChecked[v] && v != 0) {
					return false;
				}
				elmentChecked[v] = true;
			}
		}
		return true;
	}
    
	/**
	 * returns true if sudoko is solved,  otherwise returns false. 
	 * @return boolean value
	 */
	public boolean solve() {
		return solve(0, 0);
	}
	
	/**
	 * returns true if sudoko is solved by starting with an element
	 *  of the grid at i row and j col,  otherwise returns false. it is a recursive method 
	 * @param i row in the grid
	 * @param j col in the grid
	 * @return boolean value
	 */
	private boolean solve(int i, int j) {
		int n = grid.length;                     
		if (i == n || j == n) {             // a base statement, the grid has been filled
			return true;
		}
		if (grid[i][j] != 0) {              // a case that the element has already been filled 
			if (checkGrid()) {
				if (j == n - 1) {
					return solve(i + 1, 0);
				} else {
					return solve(i, j + 1);
				}
			} else {                              
				return false;
			}
		} else {                           // a case that the element has not been filled yet
			for (int k = 1; k <= 9; k++) {
				grid[i][j] = k;
				if (((j == n - 1) && checkGrid() && solve(i + 1, 0))
						|| ((j < n - 1) && checkGrid() && solve(i, j + 1))) {
					return true;
				}
			}
			grid[i][j] = 0;
			return false;
		}
	}
	
    /**
     * clear the grid, makes all element in the grid with 0 value.
     */
	public void clear() {
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				grid[i][j] = 0;
			}
		}
	}
	
	/**
     * Returns a string representation of the current sudoku grid.
     * @return String value
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid.length; j++) {
                sb.append(grid[i][j]).append(" ");
            }

            sb.append("\n");
        }

        return sb.toString();
    }
	
}
